package com.example.testmap.data;


import com.example.testmap.data.model.LoggedInUser;
import com.google.firebase.auth.FirebaseAuth;

public class LoginRepository {

    private static volatile LoginRepository instance;
    private FirebaseAuth mAuth;

    private LoginRepository() {
        mAuth = FirebaseAuth.getInstance();
    }

    public static LoginRepository getInstance() {
        if (instance == null) {
            instance = new LoginRepository();
        }
        return instance;
    }

    public void login(String username, String password, final LoginCallback callback) {
        mAuth.signInWithEmailAndPassword(username, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        LoggedInUser fakeUser = new LoggedInUser(
                                mAuth.getCurrentUser().getUid(),
                                mAuth.getCurrentUser().getEmail());
                        callback.onSuccess(new Result.Success<>(fakeUser));
                    } else {
                        callback.onError(new Result.Error(new Exception("Login failed")));
                    }
                });
    }

    public void register(String email, String password, final LoginCallback callback) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        LoggedInUser newUser = new LoggedInUser(
                                mAuth.getCurrentUser().getUid(),
                                mAuth.getCurrentUser().getEmail());
                        callback.onSuccess(new Result.Success<>(newUser));
                    } else {
                        callback.onError(new Result.Error(new Exception("Registration failed")));
                    }
                });
    }


    public interface LoginCallback {
        void onSuccess(Result.Success<LoggedInUser> result);
        void onError(Result.Error error);
    }
}
